#ifndef __CPU_CYC_COUNTER
#define __CPU_CYC_COUNTER

inline unsigned long ccnt_read (void);
inline void ccnt_init (int val);

#endif
